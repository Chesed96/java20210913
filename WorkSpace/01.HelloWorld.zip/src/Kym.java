
public class Kym {
	public static void main(String[] args) {
		System.out.println("Kym");
		
	}//main
}//Class
