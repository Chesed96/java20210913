
public class Ex03_Bool {
	public static void main(String[] args) {
		//boolean < = ( true , false ) 참 , 거짓 
		//! == NOT 1=0 , 0=1 논리식의 반적을 의미함 == !
		boolean bool = true;
		System.out.println(!bool);//true의 반전 ==> false
		bool = !bool; //true ==> false => bool
		System.out.println(bool);
		//boolean 논리형 데이터에서 앞에 !가 붙는다는것은 반전임.
	}
}
