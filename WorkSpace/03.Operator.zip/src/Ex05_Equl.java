
public class Ex05_Equl {
	public static void main(String[] args) {
		int result = 0; //0으로 초기화 
						//result라는 변수는 main method 지역안에서 사용할수있다.
		//+= , -=
		result += 10; //result =( result(0) + 10 ) == 10;
		System.out.println(result);//10
		result -= 4; // result =( result(10) - 4 ) == 6;
		System.out.println(result);
		result *= 2; // result = ( result(6) * 2 ) == 12;
		System.out.println(result);
		result /= 2; // result = ( result(12) / 2 ) == 6;
		System.out.println(result);
	}
}
