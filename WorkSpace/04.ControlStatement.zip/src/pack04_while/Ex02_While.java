package pack04_while;

public class Ex02_While {
	public static void main(String[] args) {
		//1.초기값(조건식의 기준이되는값)
		//2.조건식
		//3.증감식
		//1~100 까지의 수중에 (정수,숫자형) int
		//홀수만 콘솔창에 출력하세요.
		//1.while문 내부에 if문을 사용해야한다.
		//2.while문의 증감식이 조금 변경 되어야한다.
		
		//while(조건식) { <-블럭킹-> }
		int i = 1;
		while(i<100) {
			//첫번째방식
			if(i%2 == 1) {
				System.out.println(i);
			}
			//두번째방식
			//System.out.println(i);
			//i += 2  ;
		}
	}
}
