package pack04_while;

public class Ex01_While {
	public static void main(String[] args) {
		//for문은 사용하는 용도가 반복횟수가 정해져있는경우에 많이사용하고,
		//while문은 사용하는 용도가 반복횟수가 정확히 정해져있지 않은경우,
		//while( 1.조건식 ){
			//2.실행부
		//}
		//0.초기값(int i = 0 ;)
		int i = 0;
		while(i<10) {
			//true가 되면 실행 되는부분
			System.out.println(i);
			i++;
		}
		//for(int i = 0 ; i< 10 ; i++)<-
		//반복문에서 중요한 요소
		//1.초기값(조건식의 기준이되는값)
		//2.조건식
		//3.증감식
		
	}
}
