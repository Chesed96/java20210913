package pack04_Boolean;

public class Ex01_Boolean {
	public static void main(String[] args) {
		//boolean이라는 논리형데이터에는 (부울형)
		//true , false 만 기억 할수있다 . ▶ 조건식(알고리즘을 만들때 사용됨)
		//지금비가오냐? = x
		//만약에 지금 비가 온다면 ?( == true) 지금 온다면 진행되는 프로그램
		//						   ( == false) 지금 안온다면 진행되는 프로그램
		boolean t = true;//참 1
		boolean f = false;//거짓 0
		System.out.println("변수 t의 값은 : " + t);
		System.out.println("변수 f의 값은 : " + f);
	}
}
